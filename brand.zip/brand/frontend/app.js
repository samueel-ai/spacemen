/**
 * SPACEBOIS E-Commerce Platform
 * Complete Frontend Application
 * Includes: Product catalog, cart, wishlist, checkout, user accounts, reviews, etc.
 */

// ===== STATE MANAGEMENT =====
const state = {
    currentPage: 'home',
    products: [],
    cart: [],
    wishlist: [],
    user: null,
    selectedProduct: null,
    selectedColor: null,
    selectedSize: null,
    filters: {
        category: [],
        brand: [],
        color: [],
        size: [],
        maxPrice: 50000
    },
    sortBy: 'newest',
    currentStep: 1,
    shippingCost: 1500,
    userRating: 0
};

const placeholderImage = 'images/placeholder.svg';

// ===== PRODUCT DATABASE =====
const products = [
    // WZ / SPACEBOYS MERCH
    {
        id: 1,
        name: "WZ Skull Cap",
        brand: "wazaa",
        category: "accessories",
        description: "Low-profile skull cap available in Ash Camo and Black.",
        price: 9500,
        sku: "WZ-SK-001",
        icon: "🧢",
        imagesByColor: {
            "Ash Camo": ["images/skull cap camo.jpg", "images/skull cap camo.jpg"],
            "Black": ["images/skull cap black.jpg", "images/skull cap black.jpg"]
        },
        colors: { "Ash Camo": "#7a7a56", Black: "#111111" },
        sizes: ["ONE SIZE"],
        inventory: { "Ash Camo": { "ONE SIZE": 25 }, Black: { "ONE SIZE": 30 } },
        rating: 4.6,
        reviews: 12,
        tags: ["skullcap", "wazaa"]
    },
    {
        id: 2,
        name: "WZ Tank Top",
        brand: "wazaa",
        category: "apparel",
        description: "Lightweight tank with minimal branding. Available in Black.",
        price: 9000,
        sku: "WZ-TK-001",
        icon: "👕",
        images: ["images/front top.jpg", "images/back top.jpg"],
        colors: { Black: "#111111" },
        sizes: ["XS", "S", "M", "L", "XL", "XXL"],
        inventory: { Black: { XS: 10, S: 20, M: 30, L: 25, XL: 15, XXL: 8 } },
        rating: 4.4,
        reviews: 8,
        tags: ["tank", "wazaa"]
    },
    {
        id: 3,
        name: "Space Boys Tee",
        brand: "spacebois",
        category: "apparel",
        description: "Signature Space Boys Tee with screen-printed logo. Comes in White and Black.",
        price: 15000,
        sku: "SB-TEE-001",
        icon: "👕",
        imagesByColor: {
            White: ["images/spaceboys tee white.jpg", "images/spaceboys tee white.jpg"],
            Black: ["images/spaceboys tee black.jpg", "images/spaceboys tee black.jpg"]
        },
        colors: { White: "#ffffff", Black: "#000000" },
        sizes: ["XS", "S", "M", "L", "XL", "XXL"],
        inventory: { White: { XS: 12, S: 18, M: 20, L: 15, XL: 10, XXL: 5 }, Black: { XS: 10, S: 16, M: 18, L: 14, XL: 9, XXL: 4 } },
        rating: 4.8,
        reviews: 60,
        tags: ["spaceboys", "tee"]
    },
    {
        id: 4,
        name: "Long Sleeve Movement Tee",
        brand: "wazaa",
        category: "apparel",
        description: "Performance long sleeve tee with movement fabric. Available in White and Black.",
        price: 15000,
        sku: "WZ-LS-001",
        icon: "👕",
        imagesByColor: {
            White: ["images/tabitah crowd white.jpg", "images/tabitah crowd white.jpg"],
            Black: ["images/tabitah crowd black.jpg", "images/tabitah crowd black.jpg"]
        },
        colors: { White: "#ffffff", Black: "#000000" },
        sizes: ["XS", "S", "M", "L", "XL", "XXL"],
        inventory: { White: { XS: 8, S: 12, M: 15, L: 10, XL: 6, XXL: 3 }, Black: { XS: 10, S: 14, M: 16, L: 12, XL: 8, XXL: 4 } },
        rating: 4.7,
        reviews: 22,
        tags: ["longsleeve", "movement"]
    },
    {
        id: 5,
        name: "Long Sleeve Bone Design Tee",
        brand: "wazaa",
        category: "apparel",
        description: "Graphic bone design on premium cotton; White and Black options.",
        price: 15000,
        sku: "WZ-LS-002",
        icon: "👕",
        imagesByColor: {
            White: ["images/tabitah bones tee.jpg", "images/tabitah bones tee.jpg"],
            Black: ["images/tabitah bon tee black.jpg", "images/tabitah bon tee black.jpg"]
        },
        colors: { White: "#ffffff", Black: "#000000" },
        sizes: ["XS", "S", "M", "L", "XL", "XXL"],
        inventory: { White: { XS: 5, S: 8, M: 10, L: 9, XL: 6, XXL: 2 }, Black: { XS: 7, S: 10, M: 12, L: 11, XL: 7, XXL: 3 } },
        rating: 4.6,
        reviews: 18,
        tags: ["bone", "longsleeve"]
    },
    {
        id: 6,
        name: "WZ Ladies Wear",
        brand: "wazaa",
        category: "apparel",
        description: "Tailored ladies fit with subtle branding. White and Black.",
        price: 22000,
        sku: "WZ-LAD-001",
        icon: "👗",
        imagesByColor: {
            White: ["images/wazaa lady wear white.jpg", "images/wazaa lady wear white.jpg"],
            Black: ["images/wazaa ladies wear black.jpg", "images/wazaa ladies wear black.jpg"]
        },
        colors: { White: "#ffffff", Black: "#000000" },
        sizes: ["XS", "S", "M", "L"],
        inventory: { White: { XS: 6, S: 10, M: 12, L: 8 }, Black: { XS: 5, S: 9, M: 11, L: 7 } },
        rating: 4.5,
        reviews: 10,
        tags: ["ladies", "wazaa"]
    },
    {
        id: 7,
        name: "WZ Tee with Camo Sleeve",
        brand: "wazaa",
        category: "apparel",
        description: "Classic tee with camo sleeve detail. White and Black.",
        price: 15000,
        sku: "WZ-TEE-CAMO-001",
        icon: "👕",
        imagesByColor: {
            White: ["images/wz weakness tee white.jpg", "images/wz weakness tee white.jpg"],
            Black: ["images/wz weakness tee black.jpg", "images/wz weakness tee black.jpg"]
        },
        colors: { White: "#ffffff", Black: "#000000" },
        sizes: ["XS", "S", "M", "L", "XL", "XXL"],
        inventory: { White: { XS: 6, S: 9, M: 12, L: 10, XL: 6, XXL: 2 }, Black: { XS: 7, S: 11, M: 13, L: 12, XL: 8, XXL: 3 } },
        rating: 4.4,
        reviews: 14,
        tags: ["camo", "tee"]
    },
    {
        id: 20,
        name: "WZ Camo Sleeve Signature Tee",
        brand: "wazaa",
        category: "apparel",
        description: "Fresh black-and-white camo sleeve edition with sharp contrast and premium street-ready styling.",
        price: 15500,
        sku: "WZ-TEE-CAMO-002",
        icon: "👕",
        imagesByColor: {
            White: ["images/comment tee white.jpg", "images/comment tee white.jpg"],
            Black: ["images/wz comment tee.jpg", "images/wz comment tee.jpg"]
        },
        colors: { White: "#ffffff", Black: "#000000" },
        sizes: ["XS", "S", "M", "L", "XL", "XXL"],
        inventory: { White: { XS: 5, S: 8, M: 11, L: 9, XL: 5, XXL: 2 }, Black: { XS: 6, S: 10, M: 12, L: 11, XL: 7, XXL: 3 } },
        rating: 4.5,
        reviews: 18,
        tags: ["camo", "tee", "signature"]
    },
    {
        id: 8,
        name: "WZ Plain Black Tee",
        brand: "wazaa",
        category: "apparel",
        description: "Minimal plain black tee, premium cotton.",
        price: 9000,
        sku: "WZ-TEE-BLK-001",
        icon: "👕",
        images: ["images/wazaa plain black.jpg", "images/wazaa plain black.jpg"],
        colors: { Black: "#000000" },
        sizes: ["XS", "S", "M", "L", "XL", "XXL"],
        inventory: { Black: { XS: 20, S: 30, M: 40, L: 35, XL: 25, XXL: 10 } },
        rating: 4.3,
        reviews: 40,
        tags: ["plain", "black"]
    },

    // TABITAH MERCH
    {
        id: 9,
        name: "Tabitah Cap Trucker",
        brand: "tabitah",
        category: "accessories",
        description: "Classic trucker cap available in multiple colors.",
        price: 12000,
        sku: "TAB-TRK-001",
        icon: "🧢",
        imagesByColor: {
            Black: ["images/tabitah black cap.jpg"],
            Blue: ["images/tabitah blue cap.jpg"],
            Pink: ["images/tabitah pink cap.jpg"],
            Camo: ["images/tabitah camo cap.jpg"]
        },
        colors: { Black: "#111111", Blue: "#0077ff", Pink: "#ff2d7a", Camo: "#6b6b4a" },
        sizes: ["ONE SIZE"],
        inventory: { Black: { "ONE SIZE": 20 }, Blue: { "ONE SIZE": 18 }, Pink: { "ONE SIZE": 15 }, Camo: { "ONE SIZE": 12 } },
        rating: 4.5,
        reviews: 19,
        tags: ["cap", "tabitah"]
    },
    {
        id: 10,
        name: "Tabitah Ladies Full Wear",
        brand: "tabitah",
        category: "apparel",
        description: "Full ladies wear set available in multiple colors.",
        price: 25000,
        sku: "TAB-LAD-001",
        icon: "👗",
        imagesByColor: {
            Black: ["images/tabitah over all black.jpg", "images/images/tabitah overall white.jpg"],
            Pink: ["images/tabitah ladies wear pink.jpg"],
            "Sky Blue": ["images/tabitah ladies wear sky blue.jpg"],
            Brown: ["images/tabitah ladies wear brown.jpg"],
            White: ["images/tabitah overall white.jpg"]
        },
        colors: { Black: "#111111", Pink: "#ff2d7a", "Sky Blue": "#87ceeb", Brown: "#8b5a2b", White: "#ffffff" },
        sizes: ["XS", "S", "M", "L"],
        inventory: { Black: { XS: 6, S: 8, M: 10, L: 5 }, Pink: { XS: 4, S: 6, M: 8, L: 3 }, "Sky Blue": { XS: 3, S: 4, M: 5, L: 2 }, Brown: { XS: 2, S: 3, M: 4, L: 1 }, White: { XS: 5, S: 7, M: 9, L: 4 } },
        rating: 4.6,
        reviews: 21,
        tags: ["ladies", "tabitah"]
    },
    {
        id: 11,
        name: "Tabitah Special",
        brand: "tabitah",
        category: "apparel",
        description: "Special ladies wear with small camo detail.",
        price: 22000,
        sku: "TAB-LAD-SPC-001",
        icon: "👗",
        images: ["images/tabitah ladies wear.jpg", "images/tabitah ladies wear.jpg"],
        colors: { Default: "#000000" },
        sizes: ["XS", "S", "M", "L"],
        inventory: { Default: { XS: 5, S: 8, M: 10, L: 6 } },
        rating: 4.7,
        reviews: 14,
        tags: ["ladies", "tabitah", "special"]
    },
    {
        id: 21,
        name: "Tabitah Long Sleeves",
        brand: "tabitah",
        category: "apparel",
        description: "Comfort long sleeves, available in White, Black and Camo Gray.",
        price: 15000,
        sku: "TAB-LS-001",
        icon: "👕",
        imagesByColor: {
            White: ["images/correction white.jpg"],
            Black: ["images/correct black.jpg"],
            "Camo Gray": ["images/correction camo.jpg"]
        },
        colors: { White: "#ffffff", Black: "#000000", "Camo Gray": "#7a7a7a" },
        sizes: ["XS", "S", "M", "L", "XL"],
        inventory: { White: { XS: 6, S: 10, M: 12, L: 8, XL: 4 }, Black: { XS: 5, S: 8, M: 10, L: 7, XL: 3 }, "Camo Gray": { XS: 3, S: 5, M: 6, L: 4, XL: 2 } },
        rating: 4.4,
        reviews: 15,
        tags: ["tabitah", "longsleeve"]
    },

    // PRODUCTS WITHOUT COLOR OPTIONS (size-only)
    {
        id: 12,
        name: "Head Warmer – Space Boys",
        brand: "spacebois",
        category: "accessories",
        description: "Cozy head warmer with Space Boys logo (one design).",
        price: 8000,
        sku: "SB-HW-001",
        icon: "🎩",
        images: ["images/headwarmer SB.jpg"],
        colors: { Default: "#222222" },
        sizes: ["ONE SIZE"],
        inventory: { Default: { "ONE SIZE": 40 } },
        rating: 4.2,
        reviews: 7,
        tags: ["headwarmer"]
    },
    {
        id: 13,
        name: "Tabitah Track Suit",
        brand: "tabitah",
        category: "apparel",
        description: "Signature track suit set in premium fabric (set).",
        price: 32000,
        sku: "TAB-TS-001",
        icon: "🏃",
        images: ["images/tracksuit.jpg", "images/tracksuit.jpg"],
        colors: { Default: "#333333" },
        sizes: ["S", "M", "L", "XL"],
        inventory: { Default: { S: 6, M: 8, L: 6, XL: 3 } },
        rating: 4.5,
        reviews: 11,
        tags: ["tracksuit"]
    },
    {
        id: 14,
        name: "WZ Black Tee 1",
        brand: "wazaa",
        category: "apparel",
        description: "WZ Black Tee (style 1)",
        price: 9000,
        sku: "WZ-BLK-001",
        icon: "👕",
        images: ["images/wazaa_tshirt_front.png", "images/wazaa_tshirt_back.png"],
        colors: { Default: "#000000" },
        sizes: ["S", "M", "L", "XL"],
        inventory: { Default: { S: 12, M: 20, L: 18, XL: 10 } },
        rating: 4.3,
        reviews: 9,
        tags: ["blacktee"]
    },
    {
        id: 15,
        name: "WZ Black Tee 2",
        brand: "wazaa",
        category: "apparel",
        description: "WZ Black Tee (style 2)",
        price: 9000,
        sku: "WZ-BLK-002",
        icon: "👕",
        images: ["images/wazaa_red_tshirt_front.png", "images/wazaa_red_tshirt_back.png"],
        colors: { Default: "#000000" },
        sizes: ["S", "M", "L", "XL"],
        inventory: { Default: { S: 8, M: 16, L: 14, XL: 6 } },
        rating: 4.2,
        reviews: 6,
        tags: ["blacktee"]
    },
    {
        id: 16,
        name: "WZ Black Tee 3",
        brand: "wazaa",
        category: "apparel",
        description: "WZ Black Tee (style 3)",
        price: 9000,
        sku: "WZ-BLK-003",
        icon: "👕",
        images: ["images/wz sober tee.jpg"],
        colors: { Default: "#000000" },
        sizes: ["S", "M", "L", "XL"],
        inventory: { Default: { S: 10, M: 15, L: 12, XL: 7 } },
        rating: 4.1,
        reviews: 5,
        tags: ["blacktee"]
    },
    {
        id: 17,
        name: "WZ Trouser",
        brand: "wazaa",
        category: "apparel",
        description: "Tailored trouser for everyday wear.",
        price: 16000,
        sku: "WZ-TR-001",
        icon: "👖",
        images: ["images/wz trouser.jpg"],
        colors: { Default: "#222222" },
        sizes: ["M", "L", "XL"],
        inventory: { Default: { M: 8, L: 6, XL: 4 } },
        rating: 4.2,
        reviews: 7,
        tags: ["trouser"]
    },
    {
        id: 18,
        name: "Tabitah Grey Trouser",
        brand: "tabitah",
        category: "apparel",
        description: "Tailored trouser available in Black and Grey.",
        price: 17500,
        sku: "TAB-TR-GRY-001",
        icon: "👖",
        imagesByColor: {
            Black: ["images/new1.jpg", "images/new1.jpg"],
            Grey: ["images/new2.jpg", "images/new2.jpg"]
        },
        colors: { Black: "#111111", Grey: "#7f7f7f" },
        sizes: ["M", "L", "XL"],
        inventory: { Black: { M: 4, L: 4, XL: 2 }, Grey: { M: 6, L: 5, XL: 3 } },
        rating: 4.0,
        reviews: 4,
        tags: ["trouser"]
    },
    {
        id: 19,
        name: "Tabitah Ash Trouser",
        brand: "tabitah",
        category: "apparel",
        description: "Ash-colored trouser with modern cut.",
        price: 17500,
        sku: "TAB-TR-ASH-001",
        icon: "👖",
        images: ["images/tabitah ash trouser.jpg"],
        colors: { Default: "#bdbdbd" },
        sizes: ["M", "L", "XL"],
        inventory: { Default: { M: 5, L: 4, XL: 2 } },
        rating: 4.1,
        reviews: 3,
        tags: ["trouser"]
    }
];

// ===== INITIALIZATION =====
function init() {
    state.products = products;
    loadCartFromStorage();
    loadWishlistFromStorage();
    loadUserFromStorage();
    generateStars();
    renderHome();
    attachEventListeners();
}

// ===== STARS BACKGROUND =====
function generateStars() {
    const container = document.getElementById('stars');
    for (let i = 0; i < 200; i++) {
        const star = document.createElement('div');
        star.className = 'star';
        const size = Math.random() * 2.5 + 0.4;
        star.style.cssText = `
            width:${size}px;
            height:${size}px;
            top:${Math.random() * 100}%;
            left:${Math.random() * 100}%;
            animation-delay:${Math.random() * 5}s;
            animation-duration:${2 + Math.random() * 4}s;
        `;
        container.appendChild(star);
    }
}

// ===== NAVIGATION =====
window.navigate = function(page) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));

    // Show selected page
    const pageId = `${page}-page`;
    const pageElement = document.getElementById(pageId);
    if (pageElement) {
        pageElement.classList.add('active');
        state.currentPage = page;

        // Page-specific initialization
        switch (page) {
            case 'home':
                renderHome();
                break;
            case 'browse':
                renderBrowse();
                break;
            case 'product':
                renderProductDetails();
                break;
            case 'cart':
                renderCart();
                break;
            case 'checkout':
                renderCheckout();
                break;
            case 'wishlist':
                renderWishlist();
                break;
            case 'account':
                if (!state.user) {
                    navigate('login');
                    return;
                }
                renderAccount();
                break;
            case 'login':
                renderLogin();
                break;
            case 'register':
                renderRegister();
                break;
        }

        window.scrollTo(0, 0);
    }
}

// ===== HOME PAGE =====
function renderHome() {
    renderFeaturedProducts();
}

function renderFeaturedProducts() {
    renderProductGrid('spaceboisGrid', state.products);
}

function renderProductGrid(gridId, productsToRender) {
    const grid = document.getElementById(gridId);
    if (!grid) return;

    grid.innerHTML = '';
    productsToRender.forEach(product => {
        const card = createProductCard(product);
        grid.appendChild(card);
    });
}

function createProductCard(product) {
    const card = document.createElement('div');
    const brandColor = {
        'wazaa': 'var(--bl)',
        'tabitah': 'var(--pk)',
        'collab': 'var(--pu)'
    };

    const brandLabel = {
        'wazaa': 'WAZAA THE BRAND',
        'tabitah': 'TABITAH',
        'collab': 'SPACEBOIS COLLAB'
    };

    const buttonClass = {
        'wazaa': 'aw',
        'tabitah': 'at',
        'collab': 'as'
    };

    const productBrandLabel = brandLabel[product.brand] || 'SPACEBOYS';
    const productButtonClass = buttonClass[product.brand] || 'aw';
    const productBrandClass = `brand-${product.brand || 'default'}`;

    card.className = `pcard product-card ${productBrandClass}`;

    // determine preview image (first image for this product)
    const previewImage = getProductGalleryImages(product)[0] || placeholderImage;

    // build size selector (card-level)
    const sizeOptions = (product.sizes || []).map(s => `<option value="${s}">${s}</option>`).join('');

    // build color selector only if multiple colors exist
    const colorKeys = product.colors ? Object.keys(product.colors) : [];
    let colorSelectHtml = '';
    if (colorKeys.length > 1) {
        const colorOptions = colorKeys.map(c => `<option value="${c}">${c}</option>`).join('');
        colorSelectHtml = `<label class="card-label">Color<select id="colorSelect-${product.id}" class="card-select">${colorOptions}</select></label>`;
    }

    card.innerHTML = `
        <div class="pimg">
            <img class="pcard-img" src="${previewImage}" alt="${product.name}" onerror="this.src='${placeholderImage}'">
            <div class="pglow"></div>
        </div>
        <div class="pbody">
            <span class="ptag">${productBrandLabel}</span>
            <div class="pname">${product.name}</div>
            <div class="pdesc">${product.description}</div>
            <div class="card-controls">
                ${colorSelectHtml}
                <label class="card-label">Size<select id="sizeSelect-${product.id}" class="card-select">${sizeOptions}</select></label>
                <label class="card-label">Qty<input id="qtyInput-${product.id}" class="qty-input" type="number" min="1" value="1"></label>
            </div>
            <div class="pfoot">
                <span class="pprice">₦${product.price.toLocaleString()}</span>
                <div class="pactions">
                    <button class="aBtn ${productButtonClass}" onclick="selectProduct(${product.id})">VIEW</button>
                    <button class="aBtn secondary" onclick="addToCartFromCard(${product.id})">Add to Cart</button>
                </div>
            </div>
        </div>
    `;

    card.style.cursor = 'pointer';
    return card;
}

// add-to-cart from product card (validates selections and inventory)
function addToCartFromCard(productId) {
    const product = state.products.find(p => p.id === productId);
    if (!product) return showToast('✗ Product not found');

    const qtyEl = document.getElementById(`qtyInput-${productId}`);
    const sizeEl = document.getElementById(`sizeSelect-${productId}`);
    const colorEl = document.getElementById(`colorSelect-${productId}`);

    const quantity = qtyEl ? parseInt(qtyEl.value) || 1 : 1;
    const size = sizeEl ? sizeEl.value : (product.sizes && product.sizes[0]) || 'ONE SIZE';
    const color = colorEl ? colorEl.value : (product.colors ? Object.keys(product.colors)[0] : null);

    // Validate size
    if ((!size || (product.sizes && product.sizes[0] !== 'ONE SIZE' && !product.sizes.includes(size)))) {
        return showToast('✗ Please select a valid size');
    }

    // Validate color if required
    if (colorEl && !color) return showToast('✗ Please select a color');

    // Check inventory
    let available = 0;
    if (product.inventory && color && product.inventory[color]) {
        available = product.inventory[color][size] || 0;
    } else if (product.inventory && !color) {
        // sum across colors
        available = Object.values(product.inventory).reduce((s, c) => s + (c[size] || 0), 0);
    }

    if (available < quantity) return showToast('✗ Not enough stock');

    // Build cart item
    const cartItem = {
        productId: product.id,
        id: `${product.id}-${color || 'none'}-${size}`,
        name: product.name,
        price: product.price,
        quantity,
        color: color || 'DEFAULT',
        size: size,
        icon: product.icon
    };

    const existing = state.cart.findIndex(i => i.id === cartItem.id);
    if (existing > -1) {
        state.cart[existing].quantity += quantity;
    } else {
        state.cart.push(cartItem);
    }

    saveCartToStorage();
    updateCartCount();
    showToast(`✓ ${product.name} added to cart`);
}

function getProductGalleryImages(product, color) {
    // If explicit per-product images provided, prefer them
    if (color) {
        if (product.imagesByColor && product.imagesByColor[color] && product.imagesByColor[color].length) {
            return product.imagesByColor[color];
        }
        if (Array.isArray(product.images) && product.images.length > 0) {
            return product.images;
        }
        // fallback to a placeholder for the selected color
        const colorValue = (product.colors && product.colors[color]) || '#000000';
        const imageLabel = encodeURIComponent(`${product.name} ${color}`);
        const hexColor = colorValue.replace('#', '');
        return [`https://via.placeholder.com/900x900/${hexColor}/ffffff?text=${imageLabel}`];
    }

    // No color requested: return product.images if available, otherwise flatten imagesByColor
    if (Array.isArray(product.images) && product.images.length > 0) {
        return product.images;
    }

    if (product.imagesByColor && Object.keys(product.imagesByColor).length > 0) {
        return Object.values(product.imagesByColor).flat();
    }

    // Final fallback: generate simple placeholders per color
    if (product.colors) {
        return Object.entries(product.colors).map(([colorName, colorValue]) => {
            const imageLabel = encodeURIComponent(`${product.name} ${colorName}`);
            const hexColor = colorValue.replace('#', '');
            return `https://via.placeholder.com/900x900/${hexColor}/ffffff?text=${imageLabel}`;
        });
    }

    return [`https://via.placeholder.com/900x900/000000/ffffff?text=${encodeURIComponent(product.name)}`];
}

// ===== BROWSE PAGE =====
function renderBrowse() {
    applyFilters();
}

function applyFilters() {
    let filtered = [...state.products];

    // Category filter
    if (state.filters.category.length > 0) {
        filtered = filtered.filter(p => state.filters.category.includes(p.category));
    }

    // Brand filter
    if (state.filters.brand.length > 0) {
        filtered = filtered.filter(p => state.filters.brand.includes(p.brand));
    }

    // Price filter
    filtered = filtered.filter(p => p.price <= state.filters.maxPrice);

    // Sort
    switch (state.sortBy) {
        case 'newest':
            filtered.sort((a, b) => b.id - a.id);
            break;
        case 'price-low':
            filtered.sort((a, b) => a.price - b.price);
            break;
        case 'price-high':
            filtered.sort((a, b) => b.price - a.price);
            break;
        case 'popular':
            filtered.sort((a, b) => b.rating - a.rating);
            break;
    }

    document.getElementById('product-count').textContent = `Showing ${filtered.length} products`;
    renderProductGrid('browseGrid', filtered);
}

function clearFilters() {
    state.filters = {
        category: [],
        brand: [],
        color: [],
        size: [],
        maxPrice: 50000
    };
    state.sortBy = 'newest';

    document.querySelectorAll('.filter-checkbox').forEach(cb => cb.checked = false);
    document.getElementById('priceRange').value = 50000;
    document.getElementById('priceLabel').textContent = '₦50,000';
    document.getElementById('sortSelect').value = 'newest';

    applyFilters();
}

// Event listeners for filters
function attachEventListeners() {
    // Filter checkboxes
    document.querySelectorAll('.filter-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', (e) => {
            const filterType = e.target.dataset.filter;
            const value = e.target.value;

            if (e.target.checked) {
                if (!state.filters[filterType].includes(value)) {
                    state.filters[filterType].push(value);
                }
            } else {
                state.filters[filterType] = state.filters[filterType].filter(v => v !== value);
            }

            if (state.currentPage === 'browse') {
                applyFilters();
            }
        });
    });

    // Price range
    const priceRange = document.getElementById('priceRange');
    if (priceRange) {
        priceRange.addEventListener('input', (e) => {
            state.filters.maxPrice = parseInt(e.target.value);
            document.getElementById('priceLabel').textContent = `₦${state.filters.maxPrice.toLocaleString()}`;
            if (state.currentPage === 'browse') {
                applyFilters();
            }
        });
    }

    // Sort
    const sortSelect = document.getElementById('sortSelect');
    if (sortSelect) {
        sortSelect.addEventListener('change', (e) => {
            state.sortBy = e.target.value;
            if (state.currentPage === 'browse') {
                applyFilters();
            }
        });
    }

    // Search
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase();
            if (query.length > 0) {
                const results = state.products.filter(p =>
                    p.name.toLowerCase().includes(query) ||
                    p.description.toLowerCase().includes(query) ||
                    p.tags.some(tag => tag.includes(query))
                );
                renderProductGrid('browseGrid', results);
            } else if (state.currentPage === 'browse') {
                applyFilters();
            }
        });
    }
}

// ===== PRODUCT SELECTION & DETAILS =====
function selectProduct(productId) {
    state.selectedProduct = state.products.find(p => p.id === productId);
    state.selectedColor = null;
    state.selectedSize = null;
    state.userRating = 0;
    navigate('product');
}

function renderProductDetails() {
    const product = state.selectedProduct;
    if (!product) return;

    // Set product info
    document.getElementById('productName').textContent = product.name;
    document.getElementById('productBrand').textContent = ({
        'wazaa': 'WAZAA THE BRAND',
        'tabitah': 'TABITAH',
        'collab': 'SPACEBOIS COLLAB'
    })[product.brand];
    document.getElementById('productBrandDetail').textContent = product.brand.toUpperCase();
    document.getElementById('productDescription').textContent = product.description;
    document.getElementById('productSKU').textContent = product.sku;
    document.getElementById('productCategory').textContent = product.category.toUpperCase();
    document.getElementById('productPrice').textContent = `₦${product.price.toLocaleString()}`;
    document.getElementById('productRating').textContent = `★★★★★ (${product.reviews} reviews)`;

    // Stock status
    const stockStatus = document.getElementById('stockStatus');
    const totalStock = Object.values(product.inventory).reduce((sum, colors) =>
        sum + Object.values(colors).reduce((s, sizes) => s + Object.values(sizes).reduce((a, b) => a + b, 0), 0), 0
    );
    stockStatus.textContent = totalStock > 0 ? '✓ In Stock' : '✗ Out of Stock';
    stockStatus.style.color = totalStock > 0 ? 'var(--bl)' : 'var(--pk)';

    // Product gallery
    const galleryImages = getProductGalleryImages(product);
    const mainImage = document.getElementById('mainImage');
    mainImage.src = galleryImages[0] || placeholderImage;
    mainImage.alt = `${product.name} ${Object.keys(product.colors)[0] || ''}`;
    mainImage.onerror = () => { mainImage.src = placeholderImage; };

    const thumbnailGallery = document.getElementById('thumbnailGallery');
    thumbnailGallery.innerHTML = '';
    galleryImages.forEach((src, index) => {
        const thumb = document.createElement('div');
        thumb.className = 'thumbnail';
        if (index === 0) thumb.classList.add('active');
        thumb.innerHTML = `<img src="${src}" alt="${product.name} variant ${index + 1}" onerror="this.src='${placeholderImage}'">`;
        thumb.onclick = () => {
            setMainProductImage(src);
            document.querySelectorAll('.thumbnail').forEach(t => t.classList.remove('active'));
            thumb.classList.add('active');
        };
        thumbnailGallery.appendChild(thumb);
    });

    // Color options
    const colorOptions = document.getElementById('colorOptions');
    colorOptions.innerHTML = '';
    Object.entries(product.colors).forEach(([colorName, colorValue], index) => {
        const option = document.createElement('div');
        option.className = 'color-option';
        option.style.background = colorValue;
        option.onclick = () => {
            selectColor(colorName, colorValue);
        };
        colorOptions.appendChild(option);
    });

    // Size options
    const sizeOptions = document.getElementById('sizeOptions');
    sizeOptions.innerHTML = '';
    product.sizes.forEach(size => {
        const option = document.createElement('button');
        option.className = 'size-option';
        option.textContent = size;
        option.onclick = () => selectSize(size);
        sizeOptions.appendChild(option);
    });

    if (!state.selectedColor) {
        const [firstColorName, firstColorValue] = Object.entries(product.colors)[0] || [];
        if (firstColorName) {
            selectColor(firstColorName, firstColorValue);
        }
    }

    // Review stars setup
    document.querySelectorAll('.star').forEach(star => {
        star.classList.remove('selected');
        star.onclick = () => {
            state.userRating = parseInt(star.dataset.rating);
            document.querySelectorAll('.star').forEach((s, index) => {
                if (index < state.userRating) {
                    s.classList.add('selected');
                } else {
                    s.classList.remove('selected');
                }
            });
        };
    });

    // Similar products
    const similar = state.products.filter(p =>
        p.brand === product.brand && p.id !== product.id
    ).slice(0, 4);
    renderProductGrid('similarProductsGrid', similar);

    // Wishlist button state
    const wishlistBtn = document.getElementById('wishlistBtn');
    const isWishlisted = state.wishlist.some(item => item.id === product.id);
    wishlistBtn.textContent = isWishlisted ? '♥ Wishlist' : '♡ Wishlist';

    // Reviews
    renderReviews();

    // Reset quantity
    document.getElementById('quantityInput').value = 1;
}

function selectColor(colorName, colorValue) {
    state.selectedColor = { name: colorName, value: colorValue };

    // update color option active state
    document.querySelectorAll('.color-option').forEach((opt, index) => {
        opt.classList.toggle('active', Object.keys(state.selectedProduct.colors)[index] === colorName);
    });

    // rebuild thumbnails for the selected color when on product page
    if (state.selectedProduct) {
        const imgs = getProductGalleryImages(state.selectedProduct, colorName);
        const thumbnailGallery = document.getElementById('thumbnailGallery');
        if (thumbnailGallery) {
            thumbnailGallery.innerHTML = '';
            imgs.forEach((src, i) => {
                const thumb = document.createElement('div');
                thumb.className = 'thumbnail';
                if (i === 0) thumb.classList.add('active');
                thumb.innerHTML = `<img src="${src}" alt="${state.selectedProduct.name} variant ${i + 1}" onerror="this.src='${placeholderImage}'">`;
                thumb.onclick = () => {
                    setMainProductImage(src);
                    document.querySelectorAll('.thumbnail').forEach(t => t.classList.remove('active'));
                    thumb.classList.add('active');
                };
                thumbnailGallery.appendChild(thumb);
            });
            setMainProductImage(imgs[0]);
        }
    }

    updateInventoryDisplay();
}

function selectSize(size) {
    state.selectedSize = size;
    document.querySelectorAll('.size-option').forEach(opt => {
        opt.classList.remove('active');
        if (opt.textContent === size) {
            opt.classList.add('active');
        }
    });
    updateInventoryDisplay();
}

function updateInventoryDisplay() {
    const product = state.selectedProduct;
    if (!state.selectedColor) {
        document.getElementById('inventoryCount').textContent = '0';
        return;
    }

    const colorName = state.selectedColor.name;
    const sizes = product.inventory[colorName];

    if (state.selectedSize) {
        const count = sizes[state.selectedSize] || 0;
        document.getElementById('inventoryCount').textContent = count;
        document.getElementById('inventoryText').style.color = count > 0 ? 'var(--bl)' : 'var(--pk)';
    } else {
        const totalCount = Object.values(sizes).reduce((a, b) => a + b, 0);
        document.getElementById('inventoryCount').textContent = totalCount;
    }
}

function setMainProductImage(src) {
    const mainImage = document.getElementById('mainImage');
    if (mainImage) {
        mainImage.src = src;
    }
}

function incrementQty() {
    const input = document.getElementById('quantityInput');
    input.value = parseInt(input.value) + 1;
}

function decrementQty() {
    const input = document.getElementById('quantityInput');
    if (parseInt(input.value) > 1) {
        input.value = parseInt(input.value) - 1;
    }
}

// ===== WISHLIST =====
function toggleWishlist() {
    const product = state.selectedProduct;
    const index = state.wishlist.findIndex(item => item.id === product.id);

    if (index > -1) {
        state.wishlist.splice(index, 1);
        document.getElementById('wishlistBtn').textContent = '♡ Wishlist';
        showToast('✓ Removed from Wishlist');
    } else {
        state.wishlist.push({
            id: product.id,
            name: product.name,
            price: product.price,
            icon: product.icon,
            brand: product.brand
        });
        document.getElementById('wishlistBtn').textContent = '♥ Wishlist';
        showToast('✓ Added to Wishlist');
    }

    saveWishlistToStorage();
}

function renderWishlist() {
    const container = document.getElementById('wishlistContainer');

    if (state.wishlist.length === 0) {
        container.innerHTML = '<div class="empty-state"><h3>Your Wishlist is Empty</h3><p class="empty-state-message">Start adding items you love!</p><button class="bpri full-width-button" onclick="navigate(\'browse\')">Continue Shopping</button></div>';
        return;
    }

    container.innerHTML = '';
    state.wishlist.forEach(item => {
        const product = state.products.find(p => p.id === item.id);
        if (product) {
            const card = createProductCard(product);
            container.appendChild(card);
        }
    });
}

// ===== REVIEWS =====
function renderReviews() {
    const container = document.getElementById('reviewsContainer');
    container.innerHTML = '<p class="empty-state-message">No reviews yet. Be the first to review!</p>';
}

function submitReview() {
    if (state.userRating === 0) {
        showToast('✗ Please select a rating');
        return;
    }

    const reviewText = document.getElementById('reviewText').value.trim();
    if (!reviewText) {
        showToast('✗ Please write a review');
        return;
    }

    showToast('✓ Review submitted successfully!');
    document.getElementById('reviewText').value = '';
    state.userRating = 0;
    document.querySelectorAll('.star').forEach(s => s.classList.remove('selected'));
}

// ===== SHOPPING CART =====
function addToCart() {
    const product = state.selectedProduct;

    if (!state.selectedColor) {
        showToast('✗ Please select a color');
        return;
    }

    if (!state.selectedSize && product.sizes[0] !== 'ONE SIZE') {
        showToast('✗ Please select a size');
        return;
    }

    const quantity = parseInt(document.getElementById('quantityInput').value);

    const cartItem = {
        productId: product.id,
        name: product.name,
        price: product.price,
        color: state.selectedColor.name,
        colorValue: state.selectedColor.value,
        size: state.selectedSize || 'ONE SIZE',
        quantity: quantity,
        icon: product.icon,
        brand: product.brand
    };

    const existingItem = state.cart.findIndex(item =>
        item.productId === product.id &&
        item.color === state.selectedColor.name &&
        item.size === (state.selectedSize || 'ONE SIZE')
    );

    if (existingItem > -1) {
        state.cart[existingItem].quantity += quantity;
    } else {
        state.cart.push(cartItem);
    }

    updateCartCount();
    saveCartToStorage();
    showToast(`✓ ${product.name} added to cart!`);
}

function updateCartCount() {
    const count = state.cart.reduce((sum, item) => sum + item.quantity, 0);
    document.getElementById('cartBtn').textContent = `🛒 Cart (${count})`;
}

function renderCart() {
    const container = document.getElementById('cartItemsContainer');

    if (state.cart.length === 0) {
        container.innerHTML = '<div class="empty-state"><h3>Your Cart is Empty</h3><p class="empty-state-message">Start shopping to add items to your cart</p><button class="bpri full-width-button" onclick="navigate(\'browse\')">Continue Shopping</button></div>';
        document.getElementById('cartBtn').textContent = '🛒 Cart (0)';
        updateOrderSummary();
        return;
    }

    container.innerHTML = '';
    state.cart.forEach((item, index) => {
        const itemElement = document.createElement('div');
        itemElement.className = 'cart-item';
        itemElement.innerHTML = `
            <div class="cart-item-image">${item.icon}</div>
            <div class="cart-item-details">
                <h3>${item.name}</h3>
                <p>Color: ${item.color}</p>
                <p>Size: ${item.size}</p>
                <div class="cart-item-price">₦${item.price.toLocaleString()}</div>
            </div>
            <div class="cart-item-controls">
                <button onclick="updateCartItem(${index}, -1)">−</button>
                <input type="number" value="${item.quantity}" readonly />
                <button onclick="updateCartItem(${index}, 1)">+</button>
                <button class="cart-remove" onclick="removeFromCart(${index})">Remove</button>
            </div>
        `;
        container.appendChild(itemElement);
    });

    updateOrderSummary();
}

function updateCartItem(index, change) {
    state.cart[index].quantity += change;
    if (state.cart[index].quantity <= 0) {
        removeFromCart(index);
    } else {
        saveCartToStorage();
        updateCartCount();
        renderCart();
    }
}

function removeFromCart(index) {
    state.cart.splice(index, 1);
    saveCartToStorage();
    updateCartCount();
    renderCart();
}

function updateOrderSummary() {
    const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const shippingOptionElement = document.getElementById('shippingOption');
    const shippingOption = shippingOptionElement ? shippingOptionElement.value : 'standard';

    let shipping = 1500;
    if (shippingOption === 'express') shipping = 2500;
    if (shippingOption === 'free') shipping = 0;

    state.shippingCost = shipping;

    const total = subtotal + shipping;

    document.getElementById('subtotal').textContent = `₦${subtotal.toLocaleString()}`;
    document.getElementById('shippingCost').textContent = `₦${shipping.toLocaleString()}`;
    document.getElementById('totalPrice').textContent = `₦${total.toLocaleString()}`;
}

function updateShipping() {
    updateOrderSummary();
}

// ===== CHECKOUT =====
function renderCheckout() {
    state.currentStep = 1;
    showCheckoutStep(1);
    updateCheckoutSummary();
}

function showCheckoutStep(step) {
    document.querySelectorAll('.step').forEach(s => s.classList.remove('active'));
    document.getElementById(`step${step}`).classList.add('active');
    state.currentStep = step;
}

function nextStep(event, step) {
    event.preventDefault();
    showCheckoutStep(step + 1);
}

function updateCheckoutSummary() {
    const checkoutItems = document.getElementById('checkoutItems');
    checkoutItems.innerHTML = '';

    state.cart.forEach(item => {
        const itemDiv = document.createElement('div');
        itemDiv.className = 'checkout-item';
        itemDiv.innerHTML = `
            <span>${item.name} x${item.quantity}</span>
            <span>₦${(item.price * item.quantity).toLocaleString()}</span>
        `;
        checkoutItems.appendChild(itemDiv);
    });

    const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const total = subtotal + state.shippingCost;
    document.getElementById('checkoutTotal').textContent = `₦${total.toLocaleString()}`;
}

function processPayment() {
    if (!state.user) {
        showToast('✗ Please login to continue');
        navigate('login');
        return;
    }
    navigate('payment');
}

// ===== PAYMENT =====
async function initPaystack() {
    try {
        if (!state.cart || state.cart.length === 0) {
            showToast('✗ Cart is empty');
            return;
        }

        showToast('⏳ Preparing payment...');

        // Get shipping form data
        const form = document.getElementById('shippingForm');
        const shippingData = new FormData(form);
        const shippingAddress = {
            name: shippingData.get('fullName') || '',
            email: state.user.email,
            phone: shippingData.get('phone') || '',
            street: shippingData.get('street') || '',
            city: shippingData.get('city') || '',
            state: shippingData.get('state') || '',
            postalCode: shippingData.get('postalCode') || ''
        };

        // Get delivery option (safe lookup)
        const selectedDelivery = document.querySelector('input[name="delivery"]:checked');
        const deliveryOption = selectedDelivery ? selectedDelivery.value : 'standard';
        const deliveryCosts = { standard: 1500, express: 2500, free: 0 };

        // Create order via API
        const orderResponse = await fetch('/api/orders', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('spacebois_token') || ''}`
            },
            body: JSON.stringify({
                items: state.cart,
                shippingAddress,
                deliveryOption,
                shippingCost: deliveryCosts[deliveryOption]
            })
        });

        if (!orderResponse.ok) {
            showToast('✗ Failed to create order');
            return;
        }

        const order = await orderResponse.json();
        const orderId = order._id;

        // Initialize payment
        const paymentResponse = await fetch('/api/payments/initialize', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('spacebois_token') || ''}`
            },
            body: JSON.stringify({ orderId })
        });

        if (!paymentResponse.ok) {
            showToast('✗ Failed to initialize payment');
            return;
        }

        const paymentData = await paymentResponse.json();

        // Initialize Paystack payment modal
        const handler = PaystackPop.setup({
            key: paymentData.publicKey,
            email: paymentData.email,
            amount: paymentData.amount * 100,
            ref: paymentData.reference,
            onClose: function() {
                showToast('✗ Payment window closed');
            },
            onSuccess: function(response) {
                showToast('✓ Payment successful! Processing order...');
                completeOrder();
            }
        });

        handler.openIframe();
    } catch (error) {
        console.error('Payment error:', error);
        showToast('✗ Payment initialization failed');
    }
}

function completeOrder() {
    showToast('✓ Order confirmed successfully!');
    state.cart = [];
    updateCartCount();
    saveCartToStorage();
    setTimeout(() => {
        navigate('home');
    }, 2000);
}

// ===== USER ACCOUNTS =====
function handleLogin(event) {
    event.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    // Mock login
    state.user = {
        email: email,
        name: email.split('@')[0],
        createdAt: new Date().toLocaleDateString()
    };

    saveUserToStorage();
    showToast('✓ Login successful!');
    navigate('account');
}

function handleRegister(event) {
    event.preventDefault();
    const name = document.getElementById('registerName').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;
    const confirmPassword = document.getElementById('registerConfirmPassword').value;

    if (password !== confirmPassword) {
        showToast('✗ Passwords do not match');
        return;
    }

    // Mock registration
    state.user = {
        email: email,
        name: name,
        createdAt: new Date().toLocaleDateString()
    };

    saveUserToStorage();
    showToast('✓ Account created successfully!');
    navigate('account');
}

function renderAccount() {
    if (state.user) {
        document.getElementById('fullName').value = state.user.name || '';
        document.getElementById('email').value = state.user.email || '';
        document.getElementById('phone').value = state.user.phone || '';
    }
}

function updateProfile(event) {
    event.preventDefault();
    state.user.name = document.getElementById('fullName').value;
    state.user.phone = document.getElementById('phone').value;
    saveUserToStorage();
    showToast('✓ Profile updated successfully!');
}

function showAccountSection(section) {
    document.querySelectorAll('.account-section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.account-menu-btn').forEach(b => b.classList.remove('active'));

    document.getElementById(`${section}-section`).classList.add('active');
    event.target.classList.add('active');
}

function addAddress(event) {
    event.preventDefault();
    showToast('✓ Address added successfully!');
}

function logout() {
    state.user = null;
    localStorage.removeItem('spacebois_user');
    showToast('✓ Logged out successfully');
    navigate('home');
}

function renderLogin() {
    // Page ready
}

function renderRegister() {
    // Page ready
}

// ===== LOCAL STORAGE =====
function saveCartToStorage() {
    localStorage.setItem('spacebois_cart', JSON.stringify(state.cart));
}

function loadCartFromStorage() {
    const cart = localStorage.getItem('spacebois_cart');
    if (cart) {
        state.cart = JSON.parse(cart);
        updateCartCount();
    }
}

function saveWishlistToStorage() {
    localStorage.setItem('spacebois_wishlist', JSON.stringify(state.wishlist));
}

function loadWishlistFromStorage() {
    const wishlist = localStorage.getItem('spacebois_wishlist');
    if (wishlist) {
        state.wishlist = JSON.parse(wishlist);
    }
}

function saveUserToStorage() {
    if (state.user) {
        localStorage.setItem('spacebois_user', JSON.stringify(state.user));
    }
}

function loadUserFromStorage() {
    const user = localStorage.getItem('spacebois_user');
    if (user) {
        state.user = JSON.parse(user);
    }
}

// ===== TOAST NOTIFICATIONS =====
function showToast(message) {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => {
        toast.classList.remove('show');
    }, 2800);
}

// ===== INITIALIZATION ON PAGE LOAD =====
document.addEventListener('DOMContentLoaded', init);